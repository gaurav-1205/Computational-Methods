f =@(x) x^3 - 10*x^2 + 5
q1bisection_ep17btech11007_Gaurav(f,0.6, 0.8)
f(ans)